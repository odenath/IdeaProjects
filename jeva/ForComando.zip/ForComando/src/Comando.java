import java.util.Scanner;
public class Comando {
    public static void main(String[] args) {
 Scanner texto = new Scanner(System.in);
 String str;
        System.out.println("Entre com seu nome");
        str = texto.nextLine();
        System.out.println("Bem vindo"+str);




    }

}
