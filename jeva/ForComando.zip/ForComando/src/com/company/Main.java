package com.company;

public class Main {

    public static void main(String[] args) {
int i =1;
        for(i=1 ; i >10 ;i+=3) ;
            System.out.println(i);
    }
}
