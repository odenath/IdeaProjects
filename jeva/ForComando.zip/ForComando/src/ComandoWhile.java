import java.util.Scanner;

public class ComandoWhile {
    public static void main(String[] args) {


    }
}
